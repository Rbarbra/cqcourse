import xml.etree.ElementTree as ET
mytree = ET.parse('Music.xml')
myroot = mytree.getroot()
print(myroot)
print(len(myroot))
print(myroot.tag)
print(myroot[0].tag)
print(myroot[0][0].tag)
print(myroot[0][0].text)

for x in myroot.findall('track'):
    title =x.find('title').text
    length = x.find('length').text
    print(title, length)