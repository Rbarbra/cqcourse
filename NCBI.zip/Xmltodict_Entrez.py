import xmltodict
import Bio.Entrez as ez
ez.email = "christoph-knorr@gmx.de"

with ez.efetch(db="nucleotide", id="EU490707", retmode="xml") as handle:
    record2 = xmltodict.parse(handle)

print(record2)
print(record2["GBSet"]["GBSeq"]["GBSeq_definition"])
print(record2["GBSet"]["GBSeq"]["GBSeq_source"])
print(record2["GBSet"]["GBSeq"]["GBSeq_sequence"])