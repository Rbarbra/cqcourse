import tkinter as tk


root = tk.Tk()
w = tk.Label(root, text ="Hello World!")
w.pack()
root.mainloop()
