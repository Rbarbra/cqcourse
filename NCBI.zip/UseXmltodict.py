import xmltodict

with open('Music.xml') as fd:
    doc = xmltodict.parse(fd.read())
    
print(doc)
print("")
print(doc["tracks"])
print("")
print(doc["tracks"]["track"])
print("")
print(doc["tracks"]["track"][0])
print("")
print(doc["tracks"]["track"][0]["title"])