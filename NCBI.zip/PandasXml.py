import pandas as pd

books = pd.read_xml("Music.xml")
print(books)